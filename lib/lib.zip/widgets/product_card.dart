import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/product.dart';
import '../state/currency_provider.dart';
import '../theme/app_theme.dart';

/// A single product "key" in the register grid.
/// Depresses on tap like a real register/calculator button.
/// In edit mode, shows a delete X badge and a camera badge (to
/// upload/replace the product photo) instead of responding to
/// tap-to-add.
class ProductCard extends StatefulWidget {
  final Product product;
  final VoidCallback onTap;
  final bool isEditMode;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final ValueChanged<Uint8List>? onImageSelected;

  const ProductCard({
    super.key,
    required this.product,
    required this.onTap,
    this.isEditMode = false,
    this.onEdit,
    this.onDelete,
    this.onImageSelected,
  });

  @override
  State<ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<ProductCard> {
  bool _pressed = false;
  bool _picking = false;

  // The flat product.price becomes stale the moment a size is added
  // (it's whatever it happened to be before sizes existed, and never
  // gets updated after) — so once a product has variants, the card
  // shows "From <currency><cheapest>" instead, matching what the size picker
  // sheet actually offers. A single variant still shows "From" rather
  // than that one price outright, since more sizes could be added
  // later and the label shouldn't need to flip format at that point.
  String _priceLabel(Product product) {
    if (product.variants.isEmpty) {
      return context.money(product.price);
    }
    final cheapest = product.variants.map((v) => v.price).reduce(min);
    return 'From ${context.money(cheapest)}';
  }

  Future<void> _pickImage() async {
    if (_picking) return;
    setState(() => _picking = true);
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 800,
        imageQuality: 85,
      );
      if (picked == null) return;
      final bytes = await picked.readAsBytes();
      widget.onImageSelected?.call(bytes);
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final imageUrl = product.imageUrl;

    return Stack(
      clipBehavior: Clip.none,
      children: [
        GestureDetector(
          onTapDown: widget.isEditMode ? null : (_) => setState(() => _pressed = true),
          onTapUp: widget.isEditMode ? null : (_) => setState(() => _pressed = false),
          onTapCancel: widget.isEditMode ? null : () => setState(() => _pressed = false),
          onTap: widget.isEditMode ? widget.onEdit : widget.onTap,
          child: AnimatedScale(
            scale: _pressed ? 0.94 : 1.0,
            duration: const Duration(milliseconds: 90),
            curve: Curves.easeOut,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 90),
              decoration: BoxDecoration(
                color: AppColors.slate,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: widget.isEditMode
                      ? AppColors.ledgerRed.withOpacity(0.4)
                      : (_pressed ? AppColors.ledAmber : Colors.black.withOpacity(0.3)),
                  width: 1.5,
                ),
                boxShadow: _pressed
                    ? []
                    : [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.35),
                          blurRadius: 0,
                          offset: const Offset(0, 4),
                        ),
                      ],
              ),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
              child: Column(
                children: [
                  Expanded(
                    child: Center(
                      child: AspectRatio(
                        aspectRatio: 1,
                        child: imageUrl != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: Container(
                                  color: Colors.black.withOpacity(0.15),
                                  child: Image.network(
                                    imageUrl,
                                    fit: BoxFit.contain,
                                    loadingBuilder: (context, child, progress) {
                                      if (progress == null) return child;
                                      return const Center(
                                        child: SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(strokeWidth: 2),
                                        ),
                                      );
                                    },
                                    errorBuilder: (context, error, stackTrace) => Center(
                                      child: Text(
                                        product.emoji ?? '🛒',
                                        style: const TextStyle(fontSize: 40),
                                      ),
                                    ),
                                  ),
                                ),
                              )
                            : FittedBox(
                                child: Text(
                                  product.emoji ?? '🛒',
                                  style: const TextStyle(fontSize: 40),
                                ),
                              ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 34, // fixed slot for up to 2 lines — keeps emoji/name/price
                                // aligned at the same height on every card, regardless
                                // of how long the product name is
                    child: Center(
                      child: Text(
                        product.name,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.body(
                          size: 13.5,
                          weight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _priceLabel(product),
                    style: AppTextStyles.mono(
                      size: 14,
                      weight: FontWeight.w700,
                      color: AppColors.ledAmber,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (widget.isEditMode)
          Positioned(
            top: -11,
            left: -11,
            child: GestureDetector(
              onTap: widget.onEdit,
              child: Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppColors.tillGreen,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.charcoal, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(Icons.edit, color: Colors.white, size: 18),
              ),
            ),
          ),
        if (widget.isEditMode)
          Positioned(
            top: -11,
            right: -11,
            child: GestureDetector(
              onTap: widget.onDelete,
              child: Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppColors.ledgerRed,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.charcoal, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(Icons.close, color: Colors.white, size: 20),
              ),
            ),
          ),
        if (widget.isEditMode)
          Positioned(
            bottom: -11,
            right: -11,
            child: GestureDetector(
              onTap: _pickImage,
              child: Container(
                width: 39,
                height: 39,
                decoration: BoxDecoration(
                  color: AppColors.ledAmber,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.charcoal, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 4,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: _picking
                    ? const Padding(
                        padding: EdgeInsets.all(8),
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFF3A2600),
                        ),
                      )
                    : const Icon(Icons.photo_camera, color: Color(0xFF3A2600), size: 18),
              ),
            ),
          ),
      ],
    );
  }
}
