import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../models/product_variant.dart';
import '../state/product_provider.dart';
import '../state/currency_provider.dart';
import '../theme/app_theme.dart';

/// Drop-in "This product has sizes" section for the add/edit product
/// form (embedded directly in AddProductDialog).
///
/// - For a NEW product (not yet saved), pass [productId] as null —
///   rows are staged locally and reported via [onDraftVariantsChanged];
///   AddProductDialog forwards the staged list through its onSubmit,
///   and RegisterScreen attaches them via ProductProvider.addVariant
///   once the new product actually has an id.
/// - For an EXISTING product being edited, pass its real [productId]
///   and [initialVariants] — every add/rename/reprice/delete writes
///   straight through ProductProvider immediately, same as the rest
///   of the admin UI (no separate "Save" step for sizes).
///
/// When [trackStock] is on (the product's "Track stock" switch), each
/// size also gets an optional stock quantity field. Left blank, that
/// size shares the product's stock like before; filled in, it is
/// tracked on its own.
class ProductVariantEditor extends StatefulWidget {
  final String? productId;
  final List<ProductVariant> initialVariants;
  final bool trackStock;
  final ValueChanged<List<({String name, double price, int? stockQty})>>? onDraftVariantsChanged;

  const ProductVariantEditor({
    super.key,
    required this.productId,
    this.initialVariants = const [],
    this.trackStock = false,
    this.onDraftVariantsChanged,
  });

  @override
  State<ProductVariantEditor> createState() => _ProductVariantEditorState();
}

class _DraftRow {
  final ProductVariant? existing; // null = not yet saved to Supabase
  final TextEditingController nameCtrl;
  final TextEditingController priceCtrl;
  final TextEditingController stockCtrl;
  final FocusNode nameFocus = FocusNode();
  final FocusNode priceFocus = FocusNode();
  final FocusNode stockFocus = FocusNode();

  /// What the stock field held when it was last loaded/saved — a stock
  /// value is only written back when the text actually differs, so
  /// saving a rename never overwrites a count that changed elsewhere
  /// (e.g. a sale) while this dialog was open.
  String loadedStockText;

  _DraftRow({this.existing, required String name, required String price, String stock = ''})
      : nameCtrl = TextEditingController(text: name),
        priceCtrl = TextEditingController(text: price),
        stockCtrl = TextEditingController(text: stock),
        loadedStockText = stock;

  void dispose() {
    nameCtrl.dispose();
    priceCtrl.dispose();
    stockCtrl.dispose();
    nameFocus.dispose();
    priceFocus.dispose();
    stockFocus.dispose();
  }
}

class _ProductVariantEditorState extends State<ProductVariantEditor> {
  late bool _hasSizes;
  final List<_DraftRow> _rows = [];

  /// Decimal places for the active currency (2 for PHP, 0 for JPY…).
  int get _decimals => context.currencyRead.decimals;

  @override
  void initState() {
    super.initState();
    _hasSizes = widget.initialVariants.isNotEmpty;
    for (final v in widget.initialVariants) {
      _rows.add(_newRow(
        existing: v,
        name: v.name,
        price: v.price.toStringAsFixed(_decimals),
        stock: v.stockQty?.toString() ?? '',
      ));
    }
  }

  @override
  void dispose() {
    for (final row in _rows) {
      row.dispose();
    }
    super.dispose();
  }

  void _notifyDraftChange() {
    if (widget.productId != null) return; // existing product: writes go straight to Supabase
    widget.onDraftVariantsChanged?.call(_rows
        .map((r) => (
              name: r.nameCtrl.text.trim(),
              price: double.tryParse(r.priceCtrl.text.trim()) ?? 0,
              stockQty: widget.trackStock ? int.tryParse(r.stockCtrl.text.trim()) : null,
            ))
        .where((r) => r.name.isNotEmpty && r.price > 0)
        .toList());
  }

  /// True blur handling: onSubmitted/onEditingComplete only fire on a
  /// keyboard "Done"/"Next" action, not on tapping away to another
  /// widget (e.g. straight to the dialog's own Save button) — which
  /// was the actual bug (toggle appeared to reset because nothing
  /// had actually been committed yet). This listens for real focus
  /// loss on either field and commits then, in addition to the
  /// existing submit/editingComplete handlers.
  void _wireRow(_DraftRow row) {
    void maybeCommit(FocusNode node) {
      if (node.hasFocus) return; // only act when focus is LEAVING
      if (!mounted) return; // widget (dialog) already gone
      final index = _rows.indexOf(row);
      if (index == -1) return; // row was removed/disposed
      _commitRow(index);
    }

    row.nameFocus.addListener(() => maybeCommit(row.nameFocus));
    row.priceFocus.addListener(() => maybeCommit(row.priceFocus));
    row.stockFocus.addListener(() => maybeCommit(row.stockFocus));
  }

  _DraftRow _newRow({
    ProductVariant? existing,
    required String name,
    required String price,
    String stock = '',
  }) {
    final row = _DraftRow(existing: existing, name: name, price: price, stock: stock);
    _wireRow(row);
    return row;
  }

  void _addRow() {
    setState(() => _rows.add(_newRow(name: '', price: '')));
  }

  Future<void> _removeRow(int index) async {
    final row = _rows[index];
    if (widget.productId != null && row.existing != null) {
      setState(() => _rows.removeAt(index));
      try {
        await context.read<ProductProvider>().deleteVariant(row.existing!.id);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              backgroundColor: AppColors.slate,
              content: Text('Could not delete size — try again',
                  style: AppTextStyles.body(size: 13, color: AppColors.ledgerRed)),
            ),
          );
        }
      }
    } else {
      setState(() => _rows.removeAt(index));
      _notifyDraftChange();
    }
    row.dispose();
  }

  Future<void> _commitRow(int index) async {
    final row = _rows[index];
    final name = row.nameCtrl.text.trim();
    final price = double.tryParse(row.priceCtrl.text.trim());
    if (name.isEmpty || price == null || price <= 0) return;

    if (widget.productId == null) {
      _notifyDraftChange();
      return;
    }

    final stockText = row.stockCtrl.text.trim();
    final stock = widget.trackStock ? int.tryParse(stockText) : null;

    final provider = context.read<ProductProvider>();
    try {
      if (row.existing == null) {
        await provider.addVariant(widget.productId!, name: name, price: price, stockQty: stock);
        final matches = provider.products
            .firstWhere((p) => p.id == widget.productId)
            .variants
            .where((v) => v.name == name && v.price == price);
        if (matches.isNotEmpty && mounted) {
          setState(() {
            _rows[index] = _newRow(
              existing: matches.last,
              name: name,
              price: price.toStringAsFixed(_decimals),
              stock: stock?.toString() ?? '',
            );
          });
        }
      } else {
        final stockChanged = widget.trackStock && stockText != row.loadedStockText;
        await provider.updateVariant(
          row.existing!.id,
          name: name,
          price: price,
          stockQty: stockChanged ? stock : null,
          clearStock: stockChanged && stockText.isEmpty,
        );
        row.loadedStockText = stockText;
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppColors.slate,
            content: Text('Could not save size — try again',
                style: AppTextStyles.body(size: 13, color: AppColors.ledgerRed)),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: () {
            final next = !_hasSizes;
            setState(() {
              _hasSizes = next;
              if (next && _rows.isEmpty) {
                _rows.add(_newRow(name: '', price: ''));
              }
            });
            _notifyDraftChange();
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('This product has sizes', style: AppTextStyles.body(size: 13.5, weight: FontWeight.w600)),
                      const SizedBox(height: 2),
                      Text(
                        widget.trackStock
                            ? 'e.g. Small, Medium, Large — each with its own price. '
                                'Add a stock quantity to track a size on its own; '
                                'leave it blank to share the product\'s stock.'
                            : 'e.g. Medium, Large, Grande — each with its own price',
                        style: AppTextStyles.body(size: 11.5, color: AppColors.textMuted),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: _hasSizes,
                  activeColor: AppColors.tillGreen,
                  onChanged: (v) {
                    setState(() {
                      _hasSizes = v;
                      if (v && _rows.isEmpty) {
                        _rows.add(_newRow(name: '', price: ''));
                      }
                    });
                    _notifyDraftChange();
                  },
                ),
              ],
            ),
          ),
        ),
        if (_hasSizes) ...[
          const SizedBox(height: 6),
          ..._rows.asMap().entries.map((entry) {
            final index = entry.key;
            final row = entry.value;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Column(
                children: [
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: row.nameCtrl,
                      focusNode: row.nameFocus,
                      style: AppTextStyles.body(size: 14),
                      decoration: const InputDecoration(hintText: 'Size name (e.g. Large)'),
                      onSubmitted: (_) => _commitRow(index),
                      onEditingComplete: () => _commitRow(index),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    flex: 2,
                    child: TextField(
                      controller: row.priceCtrl,
                      focusNode: row.priceFocus,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      style: AppTextStyles.mono(size: 14, weight: FontWeight.w600, color: AppColors.ledAmber),
                      decoration: InputDecoration(hintText: context.moneyHint, prefixText: context.moneyPrefix),
                      onSubmitted: (_) => _commitRow(index),
                      onEditingComplete: () => _commitRow(index),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppColors.ledgerRed, size: 20),
                    onPressed: () => _removeRow(index),
                    tooltip: 'Remove size',
                    // Explicit minimum tap size — don't rely on the
                    // default 48x48, since a compact VisualDensity
                    // anywhere above this widget (common in dense
                    // admin/POS screens) silently shrinks it below a
                    // comfortable touch target.
                    style: IconButton.styleFrom(
                      minimumSize: const Size(44, 44),
                      tapTargetSize: MaterialTapTargetSize.padded,
                      visualDensity: VisualDensity.standard,
                    ),
                  ),
                ],
              ),
                  if (widget.trackStock)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: row.stockCtrl,
                              focusNode: row.stockFocus,
                              keyboardType: TextInputType.number,
                              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                              style: AppTextStyles.body(size: 14),
                              decoration: const InputDecoration(
                                hintText: 'Stock qty (optional)',
                              ),
                              onSubmitted: (_) => _commitRow(index),
                              onEditingComplete: () => _commitRow(index),
                            ),
                          ),
                          // Same width as the delete button above, so the
                          // stock field lines up with the price field.
                          const SizedBox(width: 44),
                        ],
                      ),
                    ),
                ],
              ),
            );
          }),
          TextButton.icon(
            onPressed: _addRow,
            icon: const Icon(Icons.add_circle_outline, color: AppColors.tillGreen, size: 18),
            label: Text('Add size', style: AppTextStyles.body(size: 12.5, weight: FontWeight.w600, color: AppColors.tillGreen)),
          ),
        ],
      ],
    );
  }
}
