import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/user.dart';
import '../state/cart_provider.dart';
import '../state/ingredient_provider.dart';
import '../state/product_provider.dart';
import '../state/recipe_provider.dart';
import '../state/store_provider.dart';
import '../state/payment_method_provider.dart';
import '../state/transaction_provider.dart';
import '../theme/app_theme.dart';

// Same URL/reasoning as store_setup_screen.dart's copy of this
// constant -- kept local rather than imported cross-screen since it's
// just a link target, not shared logic. Staff accounts land here
// without ever seeing StoreSetupScreen, so this screen needs its own
// copy for the policy to be reachable regardless of role.
const _kPrivacyPolicyUrl = 'https://merq.prohubapps.com/privacy.html';

/// Staff PIN login (Phase C: shared owner session + PIN-gated
/// staff_users table). Checked via the verify_staff_login() RPC
/// instead of the old in-memory UserProvider list.
///
/// Assumes a store-owner Supabase Auth session is already active —
/// that gets established during first-run owner signup/sign-in
/// (StoreSetupScreen), and the empty-staff_users case is handled by
/// AddSelfAsStaffScreen before this screen is ever reached. Without
/// an active session, current_store_id() resolves to nothing
/// server-side and every PIN would silently fail, so that case gets
/// its own message below rather than surfacing as a confusing
/// "Invalid name or PIN."
class LoginScreen extends StatefulWidget {
  final void Function(AppUser user) onLogin;
  const LoginScreen({super.key, required this.onLogin});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _nameCtrl = TextEditingController();
  final _pinCtrl = TextEditingController();
  final _nameFocus = FocusNode();
  String? _error;
  bool _loading = false;
  bool _signingOut = false;

  UserRole _parseRole(String? raw) {
    // verify_staff_login returns role as plain text ('admin' /
    // 'cashier'); UserRole.values.byName throws on anything else,
    // which we don't want mid-login, so fall back to the least
    // privileged role rather than crashing on an unexpected value.
    return UserRole.values.firstWhere(
      (r) => r.name == raw,
      orElse: () => UserRole.cashier,
    );
  }

  Future<void> _submit() async {
    setState(() {
      _error = null;
      _loading = true;
    });

    final name = _nameCtrl.text.trim();
    final pin = _pinCtrl.text.trim();

    if (name.isEmpty || pin.isEmpty) {
      setState(() {
        _error = 'Enter your name and PIN.';
        _loading = false;
      });
      return;
    }

    if (Supabase.instance.client.auth.currentSession == null) {
      setState(() {
        _error = 'No store session found. Sign in as the store owner first.';
        _loading = false;
      });
      return;
    }

    // TEMP DEBUG -- remove before shipping. Prints the store-owner's
    // access token to the terminal running `flutter run`, for manual
    // curl testing of ai-assistant against a real authenticated
    // session instead of the anon key.
    // ignore: avoid_print
    print('ACCESS TOKEN: ${Supabase.instance.client.auth.currentSession?.accessToken}');

    try {
      final rows = await Supabase.instance.client.rpc(
        'verify_staff_login',
        params: {'staff_name': name, 'pin': pin},
      ) as List;

      if (rows.isEmpty) {
        // Covers wrong name, wrong PIN, and a locked-out account —
        // verify_staff_login deliberately doesn't distinguish these
        // (see the schema comments), so neither does this message.
        setState(() {
          _error = 'Invalid name or PIN.';
          _loading = false;
        });
        return;
      }

      final row = rows.first as Map<String, dynamic>;
      final matched = AppUser(
        id: row['id'] as String,
        name: row['name'] as String,
        role: _parseRole(row['role'] as String?),
      );

      // Fetch-once-on-login (Phase D + Phase F) — load this store's
      // catalog and transaction history before HomeShell shows. Run in
      // parallel since neither depends on the other's result. Also
      // loads the store record and the ingredients list the same way —
      // nothing downstream depends on either.
      final productProvider = context.read<ProductProvider>();
      await Future.wait([
        productProvider.loadFromSupabase(),
        context.read<TransactionProvider>().loadFromSupabase(),
        context.read<StoreProvider>().loadFromSupabase(),
        context.read<IngredientProvider>().loadFromSupabase(),
        context.read<PaymentMethodProvider>().loadFromSupabase(),
      ]);

      // Phase E — restore any cart left over from a previous session
      // (app closed/crashed mid-sale) now that the product catalog is
      // loaded, so it can be matched against current products/prices
      // rather than blindly trusting whatever was cached.
      await context.read<CartProvider>().restoreFromDisk(productProvider.products);

      // Now that both are loaded, retry anything queued while offline.
      // Wired here (rather than inside TransactionProvider itself) so
      // stock deduction for a newly-synced sale can be triggered via
      // ProductProvider without the two providers needing to reference
      // each other directly. Fire-and-forget — login shouldn't block
      // on however long a queue of offline sales takes to replay.
      //
      // recipeProvider/ingredientProvider captured here for the same
      // reason productProvider already was — this closure fires later,
      // after this method has returned.
      final recipeProvider = context.read<RecipeProvider>();
      final ingredientProvider = context.read<IngredientProvider>();
      unawaited(
        context.read<TransactionProvider>().syncPending(
              deductStock: (items, {reference, cashierName}) async {
                await productProvider.deductStockForLineItems(items);
                try {
                  await recipeProvider.deductForLineItems(
                    items,
                    ingredientProvider,
                    reference: reference,
                    staffName: cashierName,
                  );
                } catch (_) {
                  // Swallowed deliberately, same reasoning as
                  // checkout_modal.dart's live-sale deduction —
                  // negative-stock policy is allow/no-warning, and a
                  // failure here shouldn't block the rest of the
                  // offline queue from retrying.
                }
              },
            ),
      );

      if (!mounted) return;
      setState(() => _loading = false);
      widget.onLogin(matched);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Something went wrong signing in. Please try again.';
        _loading = false;
      });
    }
  }

  /// Ends the owner's Supabase Auth session so a different store can
  /// sign in on this device -- same action and wording as
  /// HomeShell's "Sign out of store" (_confirmSignOutOfStore), just
  /// reachable from the PIN screen too, before any staffer has
  /// entered a PIN. No onLogout callback to call here (unlike
  /// HomeShell's version): main.dart's StreamBuilder is already
  /// mounted at this point (that's the only way LoginScreen gets
  /// shown), and it's listening to onAuthStateChange, so clearing the
  /// session alone is enough for it to pick up session == null and
  /// route to StoreSetupScreen on its own.
  Future<void> _confirmSignOutOfStore() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.slate,
        title: Text('Sign out of store?', style: AppTextStyles.body(size: 16, weight: FontWeight.w700)),
        content: Text(
          'This signs out of this store completely on this device. Everyone here will need to sign back in with an email and password (not a PIN) to use it again.',
          style: AppTextStyles.body(size: 13, color: AppColors.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text('Cancel', style: AppTextStyles.body(size: 13, color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text('Sign out of store', style: AppTextStyles.body(size: 13, weight: FontWeight.w700, color: AppColors.ledgerRed)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _signingOut = true);
    try {
      await Supabase.instance.client.auth.signOut();
      // Deliberately no further action on success -- the StreamBuilder
      // above this screen swaps it out for StoreSetupScreen as soon as
      // the auth state change lands, so this screen is about to be
      // unmounted rather than needing to update its own state.
    } catch (e) {
      if (!mounted) return;
      setState(() => _signingOut = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not sign out: $e', style: AppTextStyles.body(size: 13)),
          backgroundColor: AppColors.ledgerRed,
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    // This screen is reached right after the owner's email sign-in
    // (or AddSelfAsStaffScreen) -- autofocus the name field so staff
    // can start typing straight away instead of having to tap in.
    // Deferred a frame since the field isn't in the tree yet at
    // initState time.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _nameFocus.requestFocus();
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _pinCtrl.dispose();
    _nameFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 360),
            child: Container(
              padding: const EdgeInsets.fromLTRB(28, 32, 28, 28),
              decoration: BoxDecoration(
                color: AppColors.slate,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.slateBorder, width: 1),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.asset(
                      'assets/branding/logo.png',
                      width: 56,
                      height: 56,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 12),
                  RichText(
                    text: TextSpan(
                      style: AppTextStyles.mono(size: 18, weight: FontWeight.w700, letterSpacing: 1.2),
                      children: [
                        TextSpan(text: 'MERQ', style: AppTextStyles.mono(size: 18, weight: FontWeight.w700, color: AppColors.ledAmber, letterSpacing: 1.2)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'POINT OF SALE',
                    style: AppTextStyles.mono(size: 10, weight: FontWeight.w500, color: AppColors.textMuted, letterSpacing: 2),
                  ),
                  const SizedBox(height: 28),
                  _LabeledField(
                    label: 'Name',
                    controller: _nameCtrl,
                    obscure: false,
                    hint: 'Enter your name',
                    focusNode: _nameFocus,
                  ),
                  const SizedBox(height: 14),
                  _LabeledField(
                    label: 'PIN',
                    controller: _pinCtrl,
                    obscure: true,
                    hint: '••••',
                    numeric: true,
                    onSubmit: _submit,
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Text(_error!, style: AppTextStyles.body(size: 13, color: AppColors.ledgerRed)),
                  ],
                  const SizedBox(height: 22),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _loading ? null : _submit,
                      child: _loading
                          ? const SizedBox(
                              height: 18, width: 18,
                              child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF3A2600)),
                            )
                          : const Text('Sign in'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Forgot your PIN? Ask your admin to reset it in Settings → Users.',
                    textAlign: TextAlign.center,
                    style: AppTextStyles.body(size: 12, color: AppColors.textMuted),
                  ),
                  const SizedBox(height: 4),
                  TextButton(
                    onPressed: _signingOut ? null : _confirmSignOutOfStore,
                    child: _signingOut
                        ? SizedBox(
                            height: 14,
                            width: 14,
                            child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.textMuted),
                          )
                        : Text(
                            'Not your store? Sign in with email',
                            style: AppTextStyles.body(size: 12.5, color: AppColors.textMuted),
                          ),
                  ),
                  const SizedBox(height: 4),
                  TextButton(
                    onPressed: () => launchUrl(
                      Uri.parse(_kPrivacyPolicyUrl),
                      mode: LaunchMode.externalApplication,
                    ),
                    child: Text(
                      'Privacy Policy',
                      style: AppTextStyles.body(size: 12.5, color: AppColors.textMuted),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LabeledField extends StatefulWidget {
  final String label;
  final TextEditingController controller;
  final bool obscure;
  final String? hint;
  final bool numeric;
  final VoidCallback? onSubmit;
  final FocusNode? focusNode;
  const _LabeledField({
    required this.label,
    required this.controller,
    required this.obscure,
    this.hint,
    this.numeric = false,
    this.onSubmit,
    this.focusNode,
  });

  @override
  State<_LabeledField> createState() => _LabeledFieldState();
}

class _LabeledFieldState extends State<_LabeledField> {
  // Starts obscured whenever the field is obscured at all -- only
  // flips to visible if the person taps the eye icon below.
  late bool _obscured = widget.obscure;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: AppTextStyles.mono(size: 10, weight: FontWeight.w500, color: AppColors.textMuted, letterSpacing: 1),
        ),
        const SizedBox(height: 6),
        TextField(
          controller: widget.controller,
          focusNode: widget.focusNode,
          obscureText: widget.obscure && _obscured,
          keyboardType: widget.numeric ? TextInputType.number : TextInputType.text,
          inputFormatters: widget.numeric
              ? [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)]
              : null,
          style: AppTextStyles.body(size: 14),
          decoration: InputDecoration(
            hintText: widget.hint ?? (widget.obscure ? '••••••••' : 'Enter username'),
            // Only an obscured field (the PIN) gets the toggle -- Name
            // passes obscure: false and never shows it.
            suffixIcon: widget.obscure
                ? IconButton(
                    icon: Icon(
                      _obscured ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      size: 20,
                      color: AppColors.textMuted,
                    ),
                    tooltip: _obscured ? 'Show PIN' : 'Hide PIN',
                    onPressed: () => setState(() => _obscured = !_obscured),
                  )
                : null,
          ),
          onSubmitted: widget.onSubmit == null ? null : (_) => widget.onSubmit!(),
        ),
      ],
    );
  }
}
