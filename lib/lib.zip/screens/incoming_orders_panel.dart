import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../models/incoming_order.dart';
import '../state/currency_provider.dart';
import '../state/incoming_order_provider.dart';
import '../widgets/bounded_content.dart';

/// Cashier-facing list of orders customers sent from a table's QR code.
/// HomeShell provides the app bar, so this is body-only (like
/// TransactionsPanel). Pull down to refresh; new orders also arrive
/// live via IncomingOrderProvider's realtime subscription.
///
/// Accepting an order here only marks it accepted -- ringing it up as a
/// sale in the Register is a separate step and isn't wired yet.
class IncomingOrdersPanel extends StatelessWidget {
  const IncomingOrdersPanel({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<IncomingOrderProvider>();
    final pending = provider.pending;
    final recent = provider.recent;

    Widget body;
    if (provider.isLoading && provider.orders.isEmpty) {
      body = const Center(child: CircularProgressIndicator());
    } else if (provider.loadError != null && provider.orders.isEmpty) {
      body = _CenteredNote(
        text: 'Could not load orders. Pull down to try again.',
        color: AppColors.ledgerRed,
      );
    } else {
      body = ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          _SectionLabel(pending.isEmpty ? 'NEW ORDERS' : 'NEW ORDERS (${pending.length})'),
          if (pending.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 28),
              child: Center(
                child: Text(
                  'No new orders. Orders from table QR codes appear here automatically.',
                  textAlign: TextAlign.center,
                  style: AppTextStyles.body(size: 13, color: AppColors.textMuted),
                ),
              ),
            ),
          for (final order in pending) _OrderCard(key: ValueKey(order.id), order: order),
          if (recent.isNotEmpty) ...[
            const SizedBox(height: 8),
            const _SectionLabel('RECENT'),
            for (final order in recent) _OrderCard(key: ValueKey(order.id), order: order),
          ],
        ],
      );
    }

    return BoundedContent(
      child: RefreshIndicator(
        onRefresh: () => context.read<IncomingOrderProvider>().load(),
        child: body,
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 2, bottom: 10),
      child: Text(
        text,
        style: AppTextStyles.mono(size: 11, weight: FontWeight.w700, color: AppColors.textMuted, letterSpacing: 1),
      ),
    );
  }
}

class _CenteredNote extends StatelessWidget {
  final String text;
  final Color color;
  const _CenteredNote({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    // Scrollable so pull-to-refresh still works on the error state.
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        const SizedBox(height: 120),
        Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(text, textAlign: TextAlign.center, style: AppTextStyles.body(size: 14, color: color)),
          ),
        ),
      ],
    );
  }
}

class _OrderCard extends StatefulWidget {
  final IncomingOrder order;
  const _OrderCard({super.key, required this.order});

  @override
  State<_OrderCard> createState() => _OrderCardState();
}

class _OrderCardState extends State<_OrderCard> {
  bool _busy = false;

  Future<void> _run(Future<void> Function() action) async {
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Could not update this order. Please try again.', style: AppTextStyles.body(size: 13)),
            backgroundColor: AppColors.ledgerRed,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<bool> _confirm(String title, String message, String confirmLabel, {bool danger = false}) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: AppColors.slate,
        title: Text(title, style: AppTextStyles.body(size: 16, weight: FontWeight.w700)),
        content: Text(message, style: AppTextStyles.body(size: 13, color: AppColors.textSecondary)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text('Cancel', style: AppTextStyles.body(size: 13, color: AppColors.textSecondary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(
              confirmLabel,
              style: AppTextStyles.body(
                size: 13,
                weight: FontWeight.w700,
                color: danger ? AppColors.ledgerRed : AppColors.ledAmber,
              ),
            ),
          ),
        ],
      ),
    );
    return result == true;
  }

  Future<void> _accept() async {
    final order = widget.order;
    final provider = context.read<IncomingOrderProvider>();
    if (order.isOnline && !order.isPaid) {
      final ok = await _confirm(
        'Payment not confirmed yet',
        'This customer says they paid online (ref ${order.paymentReference ?? '-'}), but you haven\'t marked the payment as received. Accept the order anyway?',
        'Accept anyway',
      );
      if (!ok) return;
    }
    await _run(() => provider.accept(order));
  }

  Future<void> _reject() async {
    final order = widget.order;
    final provider = context.read<IncomingOrderProvider>();
    final ok = await _confirm(
      'Reject this order?',
      order.isOnline && order.paymentStatus != 'unpaid'
          ? 'The customer reported an online payment. If you already received it, refund them outside the app.'
          : 'The customer will not be notified in the app.',
      'Reject',
      danger: true,
    );
    if (!ok) return;
    await _run(() => provider.reject(order));
  }

  Future<void> _markPaid() async {
    final order = widget.order;
    final provider = context.read<IncomingOrderProvider>();
    await _run(() => provider.markPaid(order));
  }

  String _ago(DateTime t) {
    final d = DateTime.now().difference(t.toLocal());
    if (d.inMinutes < 1) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes} min ago';
    if (d.inHours < 24) return '${d.inHours} h ago';
    return '${d.inDays} d ago';
  }

  @override
  Widget build(BuildContext context) {
    final order = widget.order;
    final isPending = order.status == 'pending';
    final rejected = order.status == 'rejected';
    final name = (order.customerName == null || order.customerName!.isEmpty) ? null : order.customerName;

    return Opacity(
      opacity: rejected ? 0.55 : 1,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.slate,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isPending ? AppColors.ledAmber : AppColors.slateBorder,
            width: isPending ? 1.5 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    name == null ? order.tableLabel : '${order.tableLabel} · $name',
                    style: AppTextStyles.body(size: 15, weight: FontWeight.w700),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '#${order.shortId} · ${_ago(order.createdAt)}',
                  style: AppTextStyles.mono(size: 10.5, color: AppColors.textMuted),
                ),
              ],
            ),
            const SizedBox(height: 10),
            for (final item in order.items)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(
                        '${item.quantity}× ${item.displayName}',
                        style: AppTextStyles.body(size: 13.5),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(context.money(item.lineTotal), style: AppTextStyles.mono(size: 12, color: AppColors.textSecondary)),
                  ],
                ),
              ),
            const Divider(height: 22),
            Row(
              children: [
                _PaymentChip(order: order),
                const Spacer(),
                Text(context.money(order.total), style: AppTextStyles.mono(size: 16, weight: FontWeight.w700, color: AppColors.ledAmber)),
              ],
            ),
            if (order.isOnline && order.paymentReference != null) ...[
              const SizedBox(height: 8),
              SelectableText(
                'Reference: ${order.paymentReference}',
                style: AppTextStyles.mono(size: 12.5, color: AppColors.textSecondary),
              ),
            ],
            if (!isPending && !rejected)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'Accepted',
                  style: AppTextStyles.body(size: 12, weight: FontWeight.w600, color: AppColors.tillGreen),
                ),
              ),
            if (rejected)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'Rejected',
                  style: AppTextStyles.body(size: 12, weight: FontWeight.w600, color: AppColors.ledgerRed),
                ),
              ),
            if (!rejected && (isPending || !order.isPaid)) ...[
              const SizedBox(height: 12),
              if (_busy)
                const Center(
                  child: SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2)),
                )
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    if (isPending)
                      OutlinedButton(
                        onPressed: _reject,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.ledgerRed,
                          side: BorderSide(color: AppColors.ledgerRed),
                        ),
                        child: const Text('Reject'),
                      ),
                    if (!order.isPaid)
                      OutlinedButton(
                        onPressed: _markPaid,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.tillGreen,
                          side: BorderSide(color: AppColors.tillGreen),
                        ),
                        child: Text(order.isOnline ? 'Payment received' : 'Paid at counter'),
                      ),
                    if (isPending)
                      FilledButton(
                        onPressed: _accept,
                        style: FilledButton.styleFrom(
                          backgroundColor: AppColors.ledAmber,
                          foregroundColor: Colors.black,
                        ),
                        child: const Text('Accept'),
                      ),
                  ],
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _PaymentChip extends StatelessWidget {
  final IncomingOrder order;
  const _PaymentChip({required this.order});

  @override
  Widget build(BuildContext context) {
    final String label;
    final Color color;
    if (order.isPaid) {
      label = order.isOnline ? 'PAID ONLINE' : 'PAID';
      color = AppColors.tillGreen;
    } else if (order.isOnline) {
      label = 'ONLINE · VERIFY PAYMENT';
      color = AppColors.ledAmber;
    } else {
      label = 'PAY AT COUNTER';
      color = AppColors.textSecondary;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.14),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.6), width: 1),
      ),
      child: Text(label, style: AppTextStyles.mono(size: 10, weight: FontWeight.w700, color: color, letterSpacing: 0.5)),
    );
  }
}
