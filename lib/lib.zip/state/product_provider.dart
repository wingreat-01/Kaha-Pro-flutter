import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/cart_item.dart';
import '../models/product.dart';
import '../models/product_stock_movement.dart';
import '../models/product_variant.dart';
import '../models/transaction.dart';

/// Product catalog state, backed by Supabase (categories/products
/// tables). Phase D of the Supabase migration — replaces the mock-data
/// seed with a real fetch, scoped to the caller's store via RLS.
///
/// Load pattern: fetch-once-on-login, not realtime. Call
/// [loadFromSupabase] right after a successful sign-in and before
/// showing HomeShell; nothing auto-refreshes after that until the next
/// login (matches today's single-till, single-device usage).
/// Thrown by [ProductProvider.addProduct] when the store is at its
/// plan's product cap — either caught locally before any network call
/// (the common case), or surfaced from the server-side
/// `enforce_product_limit` Postgres trigger (errcode P0001) if the
/// local check and the server ever disagree (e.g. plan changed on
/// another device, or this session's plan hasn't loaded yet). The
/// trigger is the real gate; this class exists so UI code can catch a
/// specific type instead of pattern-matching on PostgrestException.
class ProductLimitExceededException implements Exception {
  final String message;
  const ProductLimitExceededException(this.message);

  @override
  String toString() => message;
}

class ProductProvider extends ChangeNotifier {
  static const String uncategorized = 'Uncategorized';
  static const String _imageBucket = 'product-images';

  /// Per-plan total-product caps (all categories combined) — mirrors
  /// the `product_limit()` function backing the Postgres trigger. This
  /// copy is UI-only (for the live counter/lock in AddProductDialog);
  /// the trigger is what actually enforces it. null = unlimited.
  static const Map<String, int?> _productLimits = {
    'free': 5,
    'starter': 10,
    'basic': 30,
    'pro': null,
  };

  final SupabaseClient _client = Supabase.instance.client;

  List<Product> _products = [];
  final List<String> _categoryNames = [];

  /// Null until [loadFromSupabase] fetches it, or if that fetch fails.
  /// Treated as "unknown" rather than defaulting to 'free', so a fetch
  /// hiccup never falsely locks a paying Basic/Pro store out of adding
  /// products in the UI — the trigger still enforces the real cap
  /// regardless of whether this loaded.
  String? _plan;
  String? get plan => _plan;

  /// Set on 'free'-plan stores per the 15-day trial window (see
  /// 20260814_006_add_trial_expiry.sql). Null for paid plans, or for a
  /// free-plan store from before that migration whose backfill somehow
  /// didn't reach it.
  DateTime? _planExpiresAt;

  /// category name -> category id, needed since the DB stores
  /// products.category_id (a FK), while the rest of the app works with
  /// plain category name strings on Product.
  final Map<String, String> _categoryIds = {};

  bool isLoading = false;
  Object? loadError;

  List<Product> get products => List.unmodifiable(_products);

  List<Product> get lowStockProducts =>
      _products.where((p) => p.isLowStock).toList();

  List<String> get categoryNames => List.unmodifiable(_categoryNames);

  List<String> get categories => ['All', ..._categoryNames];

  int productCountForCategory(String name) {
    return _products.where((p) => p.category == name).length;
  }

  /// True while a 'free'-plan store is still inside its 15-day trial
  /// window ("Free Trial" on the plan screen — everything in Pro,
  /// including unlimited products). Mirrors the same check
  /// enforce_product_limit() now does server-side, so this client-side
  /// cap and the trigger's real cap never disagree.
  bool get _isInTrial =>
      _plan == 'free' && _planExpiresAt != null && DateTime.now().isBefore(_planExpiresAt!);

  /// This store's total-product cap for its current plan. Null means
  /// unlimited (Pro, or a free-plan store still in its trial window)
  /// or the plan hasn't loaded yet — callers that need to tell those
  /// apart should check [plan] too.
  int? get productLimit {
    if (_plan == null) return null;
    if (_isInTrial) return null;
    return _productLimits[_plan];
  }

  int get productCount => _products.length;

  bool get isAtProductLimit {
    final limit = productLimit;
    return limit != null && productCount >= limit;
  }

  /// Null means unlimited (or plan not loaded). Never negative.
  int? get remainingProductSlots {
    final limit = productLimit;
    if (limit == null) return null;
    final remaining = limit - productCount;
    return remaining < 0 ? 0 : remaining;
  }

  /// Uploads a product photo to Supabase Storage and returns its public
  /// URL. Path is scoped by the signed-in owner's auth uid (this app's
  /// actual tenant boundary — a shared owner session per store, per
  /// PIN-gated staff auth) rather than a separate store_id, so the
  /// Storage RLS policy can check auth.uid() directly against the
  /// object's folder without needing a join back to the store table.
  /// upsert: true so re-uploading a photo for the same product just
  /// overwrites the old file instead of accumulating orphaned ones.
  Future<String> _uploadProductImage(String productId, Uint8List bytes) async {
    final uid = _client.auth.currentUser!.id;
    final path = '$uid/$productId.jpg';
    await _client.storage.from(_imageBucket).uploadBinary(
          path,
          bytes,
          fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true),
        );
    final baseUrl = _client.storage.from(_imageBucket).getPublicUrl(path);
    // upsert:true keeps the storage path (and therefore the public URL)
    // identical across re-uploads, so Image.network/CachedNetworkImage
    // keep serving the old cached bytes for that URL even after a
    // successful re-upload. Cache-bust with a version query param and
    // persist THIS url (not baseUrl) to product.image_url, so the fix
    // survives a fresh loadFromSupabase() too.
    return '$baseUrl?v=${DateTime.now().millisecondsSinceEpoch}';
  }

  /// Fetches this store's categories and products. Call once, right
  /// after login. Categories load first since products need the
  /// id->name map to reconstruct their category field.
  Future<void> loadFromSupabase() async {
    isLoading = true;
    loadError = null;
    notifyListeners();

    try {
      // Drives the product-count cap shown in the UI (productLimit /
      // isAtProductLimit above). Isolated in its own try/catch — a
      // failure here shouldn't take down the whole catalog load, and
      // leaving _plan null just means the UI won't show a cap this
      // session while the enforce_product_limit trigger still governs
      // actual inserts.
      try {
        final storeRow = await _client.from('stores').select('plan, plan_expires_at').single();
        _plan = storeRow['plan'] as String?;
        final expiresRaw = storeRow['plan_expires_at'] as String?;
        _planExpiresAt = expiresRaw == null ? null : DateTime.tryParse(expiresRaw);
      } catch (e) {
        debugPrint('loadFromSupabase: could not fetch store plan: $e');
      }

      final categoryRows = await _client
          .from('categories')
          .select('id, name, is_protected')
          .order('created_at', ascending: true);

      _categoryNames.clear();
      _categoryIds.clear();
      for (final row in categoryRows as List) {
        final name = row['name'] as String;
        _categoryNames.add(name);
        _categoryIds[name] = row['id'] as String;
      }

      final productRows = await _client
          .from('products')
          .select('*, categories(name), product_variants(*)')
          .order('created_at', ascending: true);

      _products = (productRows as List)
          .map((row) => _productFromRow(row as Map<String, dynamic>))
          .toList();

      isLoading = false;
      notifyListeners();
    } catch (e) {
      isLoading = false;
      loadError = e;
      notifyListeners();
      rethrow;
    }
  }

  Product _productFromRow(Map<String, dynamic> row) {
    final categoryName =
        (row['categories'] as Map<String, dynamic>?)?['name'] as String? ??
            uncategorized;
    final variantRows = (row['product_variants'] as List?) ?? const [];
    final variants = variantRows
        .map((v) => ProductVariant.fromRow(v as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return Product(
      id: row['id'] as String,
      name: row['name'] as String,
      price: (row['price'] as num).toDouble(),
      category: categoryName,
      emoji: row['emoji'] as String?,
      imageUrl: row['image_url'] as String?,
      stockQty: row['stock_qty'] as int,
      lowStockThreshold: row['low_stock_threshold'] as int,
      trackStock: row['track_stock'] as bool? ?? false,
      unit: row['unit'] as String? ?? 'pc',
      unitLabel: row['unit_label'] as String?,
      costPerUnit: (row['cost_per_unit'] as num?)?.toDouble(),
      variants: variants,
      showOnQrMenu: row['show_on_qr_menu'] as bool? ?? true,
    );
  }

  Future<void> addCategory(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty || _categoryNames.contains(trimmed)) return;

    // Optimistic local add so the UI feels instant.
    _categoryNames.add(trimmed);
    notifyListeners();

    try {
      final row = await _client
          .from('categories')
          .insert({'name': trimmed})
          .select('id')
          .single();
      _categoryIds[trimmed] = row['id'] as String;
    } catch (e) {
      // Roll back on failure (e.g. a race with another device adding
      // the same name — unique(store_id, name) would reject it).
      _categoryNames.remove(trimmed);
      notifyListeners();
      rethrow;
    }
  }

  Future<void> renameCategory(String oldName, String newName) async {
    final trimmed = newName.trim();
    if (trimmed.isEmpty) return;
    if (oldName == uncategorized) return; // DB trigger would reject this too
    final index = _categoryNames.indexOf(oldName);
    if (index == -1) return;
    final categoryId = _categoryIds[oldName];
    if (categoryId == null) return;

    final previous = _categoryNames[index];
    _categoryNames[index] = trimmed;
    _categoryIds.remove(oldName);
    _categoryIds[trimmed] = categoryId;
    for (var i = 0; i < _products.length; i++) {
      if (_products[i].category == oldName) {
        _products[i] = _products[i].copyWith(category: trimmed);
      }
    }
    notifyListeners();

    try {
      await _client.from('categories').update({'name': trimmed}).eq('id', categoryId);
    } catch (e) {
      // Roll back the rename locally.
      _categoryNames[index] = previous;
      _categoryIds.remove(trimmed);
      _categoryIds[previous] = categoryId;
      for (var i = 0; i < _products.length; i++) {
        if (_products[i].category == trimmed) {
          _products[i] = _products[i].copyWith(category: previous);
        }
      }
      notifyListeners();
      rethrow;
    }
  }

  Future<void> deleteCategory(String name) async {
    if (name == uncategorized) return;
    final categoryId = _categoryIds[name];
    if (categoryId == null) return;
    if (!_categoryNames.remove(name)) return;

    if (!_categoryNames.contains(uncategorized)) {
      _categoryNames.add(uncategorized);
    }
    for (var i = 0; i < _products.length; i++) {
      if (_products[i].category == name) {
        _products[i] = _products[i].copyWith(category: uncategorized);
      }
    }
    notifyListeners();

    try {
      // Single RPC call — reassigns products to Uncategorized and
      // deletes the category row atomically server-side.
      await _client.rpc('delete_category', params: {'target_category_id': categoryId});
      _categoryIds.remove(name);
    } catch (e) {
      // Not attempting a full local rollback here since the products
      // reassignment above is harmless either way (Uncategorized is a
      // valid fallback); re-fetch to get back to a known-good state.
      await loadFromSupabase();
      rethrow;
    }
  }

  /// Returns the new product's id — needed by callers that stage
  /// variants (sizes) in the add-product dialog before the product
  /// exists yet, so they can attach them right after creation via
  /// [addVariant].
  Future<String> addProduct({
    required String name,
    required double price,
    required String category,
    String? emoji,
    Uint8List? imageBytes,
    int stockQty = 0,
    int lowStockThreshold = 5,
    bool trackStock = false,
    String unit = 'pc',
    String? unitLabel,
  }) async {
    // Local pre-check — catches the common case instantly, no network
    // round trip, and avoids creating a new category (addCategory
    // below) for a product that's about to be rejected anyway. Not
    // the real gate: the enforce_product_limit trigger is (see the
    // catch block further down), since this check can be stale if the
    // plan changed on another device or hasn't loaded this session.
    if (isAtProductLimit) {
      throw ProductLimitExceededException(
        'Product limit reached for your plan ($productLimit max). '
        'Upgrade to add more products.',
      );
    }

    if (!_categoryNames.contains(category)) {
      await addCategory(category);
    }
    final categoryId = _categoryIds[category];
    if (categoryId == null) {
      throw StateError('Could not resolve category id for "$category"');
    }

    try {
      final row = await _client
          .from('products')
          .insert({
            'name': name,
            'price': price,
            'category_id': categoryId,
            'emoji': (emoji == null || emoji.trim().isEmpty) ? null : emoji.trim(),
            'stock_qty': stockQty,
            'low_stock_threshold': lowStockThreshold,
            'track_stock': trackStock,
            'unit': unit,
            'unit_label': (unitLabel == null || unitLabel.trim().isEmpty) ? null : unitLabel.trim(),
          })
          .select()
          .single();

      final newId = row['id'] as String;
      String? imageUrl;
      if (imageBytes != null) {
        try {
          imageUrl = await _uploadProductImage(newId, imageBytes);
          final updated = await _client
              .from('products')
              .update({'image_url': imageUrl})
              .eq('id', newId)
              .select();
          if ((updated as List).isEmpty) {
            // RLS silently blocked the update — no exception, but the
            // row wasn't touched. Surface this like any other failure
            // rather than pretending it worked.
            throw StateError('image_url update matched no rows (RLS?) for product $newId');
          }
        } catch (e) {
          // Product row is already created — don't fail the whole add
          // over a photo upload hiccup. It just comes in without a
          // photo; the camera badge in edit mode lets it be added again.
          debugPrint('addProduct: image upload/save failed for $newId: $e');
          imageUrl = null;
        }
      }

      _products.add(Product(
        id: newId,
        name: name,
        price: price,
        category: category,
        emoji: (emoji == null || emoji.trim().isEmpty) ? null : emoji.trim(),
        imageUrl: imageUrl,
        stockQty: stockQty,
        lowStockThreshold: lowStockThreshold,
        trackStock: trackStock,
        unit: unit,
        unitLabel: (unitLabel == null || unitLabel.trim().isEmpty) ? null : unitLabel.trim(),
      ));
      notifyListeners();
      return newId;
    } catch (e) {
      // The real gate: enforce_product_limit trigger rejects the
      // insert server-side (errcode P0001) if the local pre-check
      // above was stale — e.g. another device added the last slot in
      // the gap between the check and this request landing.
      if (e is PostgrestException && e.code == 'P0001') {
        throw ProductLimitExceededException(e.message);
      }
      rethrow;
    }
  }

  /// Full edit — name, price, category, emoji. The general-purpose
  /// counterpart to [updateProductCategory] (which this now delegates
  /// to when only the category actually changes, so there's one write
  /// path instead of two slightly different ones).
  Future<void> updateProduct(
    String id, {
    required String name,
    required double price,
    required String category,
    String? emoji,
    bool? trackStock,
    String? unit,
    String? unitLabel,
  }) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final previous = _products[index];

    if (!_categoryNames.contains(category)) {
      await addCategory(category);
    }
    final categoryId = _categoryIds[category];
    if (categoryId == null) return;

    final trimmedEmoji = (emoji == null || emoji.trim().isEmpty) ? null : emoji.trim();
    final resolvedTrackStock = trackStock ?? previous.trackStock;
    final resolvedUnit = unit ?? previous.unit;
    final resolvedUnitLabel = unit == null ? previous.unitLabel : unitLabel;

    _products[index] = Product(
      id: previous.id,
      name: name,
      price: price,
      category: category,
      emoji: trimmedEmoji,
      imageUrl: previous.imageUrl,
      stockQty: previous.stockQty,
      lowStockThreshold: previous.lowStockThreshold,
      trackStock: resolvedTrackStock,
      unit: resolvedUnit,
      unitLabel: resolvedUnitLabel,
      costPerUnit: previous.costPerUnit,
      variants: previous.variants,
      showOnQrMenu: previous.showOnQrMenu,
    );
    notifyListeners();

    try {
      await _client.from('products').update({
        'name': name,
        'price': price,
        'category_id': categoryId,
        'emoji': trimmedEmoji,
        'track_stock': resolvedTrackStock,
        'unit': resolvedUnit,
        'unit_label': resolvedUnitLabel,
      }).eq('id', id);
    } catch (e) {
      _products[index] = previous;
      notifyListeners();
      rethrow;
    }
  }

  /// Reassigns an existing product to a different category — the
  /// missing piece for getting a product out of Uncategorized (there
  /// was previously no way to change a product's category after
  /// creation at all; the only "edit" that existed was
  /// [updateProductImage]). Creates the target category first if it
  /// doesn't exist yet, same as [addProduct] does. Delegates to
  /// [updateProduct] with the product's existing name/price/emoji
  /// unchanged.
  Future<void> updateProductCategory(String id, String newCategory) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final previous = _products[index];
    if (previous.category == newCategory) return;

    await updateProduct(
      id,
      name: previous.name,
      price: previous.price,
      category: newCategory,
      emoji: previous.emoji,
      trackStock: previous.trackStock,
    );
  }

  Future<void> removeProduct(String id) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final removed = _products[index];
    _products.removeAt(index);
    notifyListeners();

    try {
      await _client.from('products').delete().eq('id', id);
    } catch (e) {
      _products.insert(index, removed);
      notifyListeners();
      rethrow;
    }
  }

  /// Adds a size/option to a product (e.g. "Large" for ₱110). Not
  /// optimistic — the row is inserted first so the new variant gets a
  /// real id before it lands in local state, since [updateVariant] and
  /// [deleteVariant] key off that id. Toggling "this product has
  /// sizes" on in the admin UI is just calling this once; the product
  /// itself needs no separate flag (see [Product.hasVariants]).
  ///
  /// Returns the new variant's real id — register_screen.dart needs
  /// this immediately after a brand-new product's sizes save, to
  /// resolve any recipe rows staged against a particular size (see
  /// RecipeEditor.sizes doc) to their real variant_id. Returns '' on
  /// the two early-return paths below (product not found locally /
  /// blank name) — same empty-string "this one failed" convention
  /// register_screen.dart's savedVariantIds list already expects.
  Future<String> addVariant(
    String productId, {
    required String name,
    required double price,
    int? stockQty, // optional per-size stock; null = shares product stock
  }) async {
    final index = _products.indexWhere((p) => p.id == productId);
    if (index < 0) return '';
    final trimmedName = name.trim();
    if (trimmedName.isEmpty) return '';

    final currentVariants = _products[index].variants;
    final nextSortOrder = currentVariants.isEmpty
        ? 0
        : currentVariants.map((v) => v.sortOrder).reduce((a, b) => a > b ? a : b) + 1;

    final row = await _client
        .from('product_variants')
        .insert({
          'product_id': productId,
          'name': trimmedName,
          'price': price,
          'sort_order': nextSortOrder,
          // Only sent when set, so adding a plain size keeps working
          // even before the stock_qty column migration has been run.
          if (stockQty != null) 'stock_qty': stockQty < 0 ? 0 : stockQty,
        })
        .select()
        .single();

    final variant = ProductVariant.fromRow(row);
    _products[index] = _products[index].copyWith(
      variants: [...currentVariants, variant],
    );
    notifyListeners();
    await _syncProductStockFromVariants(productId);
    return variant.id;
  }

  /// Renames and/or repriced an existing size. Optimistic — the size
  /// list in the admin editor updates instantly, rolled back if the
  /// write fails.
  ///
  /// [stockQty] sets this size's own stock count; [clearStock] puts it
  /// back to "shares the product's stock" (null). This is the quiet
  /// "setup" path used by the product editor — it does not write an
  /// Inventory Movements entry. Counts changed from the Inventory
  /// screen go through [setVariantStock] / [adjustVariantStock], which
  /// do.
  Future<void> updateVariant(
    String variantId, {
    String? name,
    double? price,
    int? stockQty,
    bool clearStock = false,
  }) async {
    var productIndex = -1;
    var variantIndex = -1;
    for (var i = 0; i < _products.length; i++) {
      final vi = _products[i].variants.indexWhere((v) => v.id == variantId);
      if (vi >= 0) {
        productIndex = i;
        variantIndex = vi;
        break;
      }
    }
    if (productIndex < 0) return;

    final trimmedName = name?.trim();
    if (trimmedName != null && trimmedName.isEmpty) return;

    final previousVariants = _products[productIndex].variants;
    final previous = previousVariants[variantIndex];
    final clampedStock = (stockQty != null && stockQty < 0) ? 0 : stockQty;
    final updated = previous.copyWith(
      name: trimmedName,
      price: price,
      stockQty: clampedStock,
      clearStockQty: clearStock,
    );

    final nextVariants = [...previousVariants];
    nextVariants[variantIndex] = updated;
    _products[productIndex] = _products[productIndex].copyWith(variants: nextVariants);
    notifyListeners();

    try {
      await _client.from('product_variants').update({
        if (trimmedName != null) 'name': trimmedName,
        if (price != null) 'price': price,
        if (clearStock || clampedStock != null)
          'stock_qty': clearStock ? null : clampedStock,
      }).eq('id', variantId);
    } catch (e) {
      final rollback = [...previousVariants];
      _products[productIndex] = _products[productIndex].copyWith(variants: rollback);
      notifyListeners();
      rethrow;
    }
    if (clearStock || clampedStock != null) {
      await _syncProductStockFromVariants(_products[productIndex].id);
    }
  }

  /// Removes a size. Optimistic with rollback, same pattern as
  /// [removeProduct]. Existing sale records keep their
  /// variant_name/variant_id snapshot on transaction_line_items
  /// regardless (variant_id set null via ON DELETE SET NULL, the name
  /// text stays put) — deleting a size never rewrites past receipts.
  Future<void> deleteVariant(String variantId) async {
    var productIndex = -1;
    var variantIndex = -1;
    for (var i = 0; i < _products.length; i++) {
      final vi = _products[i].variants.indexWhere((v) => v.id == variantId);
      if (vi >= 0) {
        productIndex = i;
        variantIndex = vi;
        break;
      }
    }
    if (productIndex < 0) return;

    final previousVariants = _products[productIndex].variants;
    final removed = previousVariants[variantIndex];
    final nextVariants = [...previousVariants]..removeAt(variantIndex);
    _products[productIndex] = _products[productIndex].copyWith(variants: nextVariants);
    notifyListeners();

    try {
      await _client.from('product_variants').delete().eq('id', variantId);
    } catch (e) {
      final rollback = [...nextVariants]..insert(variantIndex, removed);
      _products[productIndex] = _products[productIndex].copyWith(variants: rollback);
      notifyListeners();
      rethrow;
    }
    await _syncProductStockFromVariants(_products[productIndex].id);
  }

  /// Uploads a new/replacement photo for an existing product and
  /// persists its URL. Call this from the camera badge in edit mode
  /// (ProductCard.onImageSelected). Photo won't show until this
  /// resolves — there's no optimistic local preview here, since the
  /// picker's own loading spinner already covers that gap, and we'd
  /// rather not show a picked photo that then silently fails to save.
  Future<void> updateProductImage(String id, Uint8List imageBytes) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;

    final imageUrl = await _uploadProductImage(id, imageBytes);
    final updated = await _client
        .from('products')
        .update({'image_url': imageUrl})
        .eq('id', id)
        .select();
    if ((updated as List).isEmpty) {
      // RLS blocked the update — Supabase doesn't throw for this, it
      // just matches zero rows and returns success. Without this
      // check, the photo would show in this session (from the local
      // copyWith below) but silently never actually persist, which is
      // exactly the bug that motivated adding this check.
      throw StateError('image_url update matched no rows (RLS?) for product $id');
    }

    _products[index] = _products[index].copyWith(imageUrl: imageUrl);
    notifyListeners();
  }

  /// Adds/subtracts stock. Manual changes (the +/- buttons in
  /// Inventory) are also written to product_stock_movements so they
  /// show up in Inventory Movements. Checkout deductions pass
  /// `logMovement: false` -- sales already live in Transactions, and
  /// Inventory Movements reads them from there rather than keeping a
  /// second copy.
  Future<void> adjustStock(
    String id,
    int delta, {
    String reason = 'Manual adjustment',
    String? staffName,
    String? note,
    bool logMovement = true,
    String? variantName, // for a size that shares the product-level stock
  }) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final product = _products[index];
    final current = product.stockQty;
    final next = (current + delta) < 0 ? 0 : current + delta;
    await _writeStock(id, index, next);
    if (logMovement) {
      await _logMovement(product, next - current,
          reason: reason, staffName: staffName, note: note, variantName: variantName);
    }
  }

  /// Per-size counterpart of [adjustStock]. Moves the size's own
  /// count; if that size has no count of its own (stockQty == null) it
  /// falls back to the product-level stock, same as a sale would.
  Future<void> adjustVariantStock(
    String productId,
    String variantId,
    int delta, {
    String reason = 'Manual adjustment',
    String? staffName,
    String? note,
    bool logMovement = true,
  }) async {
    final product = _productById(productId);
    final variant = _variantById(productId, variantId);
    if (product == null || variant == null) return;

    final current = variant.stockQty;
    if (current == null) {
      await adjustStock(productId, delta,
          reason: reason,
          staffName: staffName,
          note: note,
          logMovement: logMovement,
          variantName: variant.name);
      return;
    }

    final next = (current + delta) < 0 ? 0 : current + delta;
    await _writeVariantStock(productId, variantId, next);
    if (logMovement) {
      await _logMovement(product, next - current,
          reason: reason, staffName: staffName, note: note, variantName: variant.name);
    }
  }

  /// Per-size counterpart of [setStock] (Inventory's stock dialog).
  /// Logged as the difference from the previous count. Also turns on
  /// separate tracking for a size that didn't have a count yet.
  Future<void> setVariantStock(
    String productId,
    String variantId,
    int quantity, {
    String? staffName,
  }) async {
    final product = _productById(productId);
    final variant = _variantById(productId, variantId);
    if (product == null || variant == null) return;

    final next = quantity < 0 ? 0 : quantity;
    final before = variant.stockQty ?? 0;
    await _writeVariantStock(productId, variantId, next);
    await _logMovement(product, next - before,
        reason: 'Stock count', staffName: staffName, variantName: variant.name);
  }

  Product? _productById(String productId) {
    for (final p in _products) {
      if (p.id == productId) return p;
    }
    return null;
  }

  /// Looks the size up in the live catalog (not in a cart/receipt
  /// snapshot, whose copy of the size can be stale by the time the
  /// sale is deducted).
  ProductVariant? _variantById(String productId, String? variantId) {
    if (variantId == null || variantId.isEmpty) return null;
    final product = _productById(productId);
    if (product == null) return null;
    for (final v in product.variants) {
      if (v.id == variantId) return v;
    }
    return null;
  }

  Future<void> _writeVariantStock(String productId, String variantId, int next) async {
    final previous = _variantById(productId, variantId)?.stockQty;
    if (!_patchVariant(productId, variantId, (v) => v.copyWith(stockQty: next))) return;
    notifyListeners();

    try {
      await _client.from('product_variants').update({'stock_qty': next}).eq('id', variantId);
    } catch (e) {
      _patchVariant(
        productId,
        variantId,
        (v) => v.copyWith(stockQty: previous, clearStockQty: previous == null),
      );
      notifyListeners();
      rethrow;
    }
    await _syncProductStockFromVariants(productId);
  }

  bool _patchVariant(
    String productId,
    String variantId,
    ProductVariant Function(ProductVariant v) change,
  ) {
    final pi = _products.indexWhere((p) => p.id == productId);
    if (pi < 0) return false;
    final current = _products[pi].variants;
    final vi = current.indexWhere((v) => v.id == variantId);
    if (vi < 0) return false;
    final next = [...current];
    next[vi] = change(current[vi]);
    _products[pi] = _products[pi].copyWith(variants: next);
    return true;
  }

  /// When EVERY size has its own count, the product-level stock_qty
  /// column is kept equal to their sum. Nothing in the app reads it in
  /// that mode, but it keeps server-side logic that only knows about
  /// products.stock_qty (e.g. the QR menu hiding sold-out items)
  /// working. Best-effort: a failure here never undoes the real stock
  /// change. Not touched while any size still shares the product
  /// count, since then stock_qty is that shared pool.
  Future<void> _syncProductStockFromVariants(String productId) async {
    final product = _productById(productId);
    if (product == null) return;
    if (product.variants.isEmpty || product.variants.any((v) => v.stockQty == null)) return;
    final sum = product.variants.fold<int>(0, (total, v) => total + v.stockQty!);
    if (sum == product.stockQty) return;

    try {
      await _client.from('products').update({'stock_qty': sum}).eq('id', productId);
      final index = _products.indexWhere((p) => p.id == productId);
      if (index >= 0) {
        _products[index] = _products[index].copyWith(stockQty: sum);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('_syncProductStockFromVariants: could not mirror total for $productId: $e');
    }
  }

  /// Sets stock to an exact count (Inventory's stock dialog). Logged
  /// as the difference from the previous count.
  Future<void> setStock(String id, int quantity, {String? staffName}) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final product = _products[index];
    final next = quantity < 0 ? 0 : quantity;
    await _writeStock(id, index, next);
    await _logMovement(product, next - product.stockQty, reason: 'Stock count', staffName: staffName);
  }

  /// Best-effort audit row for a manual stock change -- same idea as
  /// IngredientProvider.recordManualAdjustment: a failed log write
  /// never undoes the real stock change. Name and unit are stored as
  /// snapshots so history still reads correctly if the product is
  /// later renamed or deleted.
  Future<void> _logMovement(
    Product product,
    int delta, {
    required String reason,
    String? staffName,
    String? note,
    String? variantName,
  }) async {
    if (delta == 0) return;
    try {
      await _client.from('product_stock_movements').insert({
        'product_id': product.id,
        'product_name': product.name,
        if (variantName != null) 'variant_name': variantName,
        'unit': product.unitDisplay,
        'delta': delta,
        'reason': reason,
        'note': note,
        'staff_name': staffName,
      });
    } catch (_) {
      // Swallowed deliberately -- see doc comment above.
    }
  }

  /// Manual product stock movements for a date range, newest first --
  /// backs the Inventory Movements screen. [from] inclusive, [to]
  /// exclusive.
  Future<List<ProductStockMovement>> loadMovements({
    required DateTime from,
    required DateTime to,
    int limit = 1000,
  }) async {
    final rows = await _client
        .from('product_stock_movements')
        .select()
        .gte('created_at', from.toUtc().toIso8601String())
        .lt('created_at', to.toUtc().toIso8601String())
        .order('created_at', ascending: false)
        .limit(limit);

    return (rows as List)
        .map((r) => ProductStockMovement.fromRow(r as Map<String, dynamic>))
        .toList();
  }

  Future<void> _writeStock(String id, int index, int next) async {
    final previous = _products[index].stockQty;
    _products[index] = _products[index].copyWith(stockQty: next);
    notifyListeners();

    try {
      await _client.from('products').update({'stock_qty': next}).eq('id', id);
    } catch (e) {
      _products[index] = _products[index].copyWith(stockQty: previous);
      notifyListeners();
      rethrow;
    }
  }

  /// Toggles whether this product shows on the customer-facing QR
  /// ordering page (Settings → QR Menu). Same optimistic-update shape
  /// as [_writeStock] — flip locally first, roll back on failure.
  Future<void> setQrMenuVisibility(String id, bool visible) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index == -1) return;

    final previous = _products[index].showOnQrMenu;
    _products[index] = _products[index].copyWith(showOnQrMenu: visible);
    notifyListeners();

    try {
      await _client.from('products').update({'show_on_qr_menu': visible}).eq('id', id);
    } catch (e) {
      _products[index] = _products[index].copyWith(showOnQrMenu: previous);
      notifyListeners();
      rethrow;
    }
  }

  /// Deducts stock for a completed sale. Only for products with
  /// [Product.trackStock] on (drinks/cups) — food items you count and
  /// restock by hand are untouched by checkout. Fires one update per
  /// line item — fine at today's single-till sale volume; worth
  /// batching into a single RPC later if that ever becomes a
  /// bottleneck.
  Future<void> deductStockForSale(List<CartItem> soldItems) async {
    for (final item in soldItems) {
      if (!item.product.trackStock) continue;
      // A size with its own count is deducted from that count; every
      // other sale (no size, or a size that shares the product's
      // stock) comes out of the product-level count as before. The
      // size is re-read from the live catalog since the cart's copy
      // can be stale.
      final live = _variantById(item.product.id, item.selectedVariant?.id);
      if (live != null && live.stockQty != null) {
        await adjustVariantStock(item.product.id, live.id, -item.quantity, logMovement: false);
      } else {
        await adjustStock(item.product.id, -item.quantity, logMovement: false);
      }
    }
  }

  /// Same deduction, but from a queued offline sale's saved
  /// TransactionLineItem snapshots instead of live CartItems — used
  /// when a sale that couldn't reach Supabase at checkout time finally
  /// syncs later. By then there's no CartItem/Product object left,
  /// only the flat sale record TransactionProvider persisted to disk,
  /// so trackStock is looked up from the current catalog by id.
  Future<void> deductStockForLineItems(List<TransactionLineItem> items) async {
    for (final item in items) {
      if (item.productId.isEmpty) continue; // product was deleted before this synced
      final matches = _products.where((p) => p.id == item.productId);
      if (matches.isEmpty || !matches.first.trackStock) continue;
      final live = _variantById(item.productId, item.variantId);
      if (live != null && live.stockQty != null) {
        await adjustVariantStock(item.productId, live.id, -item.quantity, logMovement: false);
      } else {
        await adjustStock(item.productId, -item.quantity, logMovement: false);
      }
    }
  }

  /// Sets what one unit of this product costs the store, or clears it
  /// when [cost] is null ("not set"). Optimistic with rollback, same as
  /// [setLowStockThreshold]. Negative values are clamped to 0.
  Future<void> setCostPerUnit(String id, double? cost) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final previous = _products[index];
    final next = (cost != null && cost < 0) ? 0.0 : cost;
    _products[index] = previous.copyWith(costPerUnit: next, clearCostPerUnit: next == null);
    notifyListeners();

    try {
      await _client.from('products').update({'cost_per_unit': next}).eq('id', id);
    } catch (e) {
      _products[index] = previous;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> setLowStockThreshold(String id, int threshold) async {
    final index = _products.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final clamped = threshold < 0 ? 0 : threshold;
    final previous = _products[index].lowStockThreshold;
    _products[index] = _products[index].copyWith(lowStockThreshold: clamped);
    notifyListeners();

    try {
      await _client.from('products').update({'low_stock_threshold': clamped}).eq('id', id);
    } catch (e) {
      _products[index] = _products[index].copyWith(lowStockThreshold: previous);
      notifyListeners();
      rethrow;
    }
  }
}
