import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/incoming_order.dart';

/// Orders customers send from a table's QR page (order.html), kept live
/// with Supabase Realtime so the cashier sees them without refreshing.
///
/// HomeShell calls [start] when it mounts and [stop] when it goes away.
/// Realtime is only used as a "something changed" signal -- every event
/// simply reloads the list, because order_items rows aren't in the
/// realtime publication and a reload is cheap at this volume.
///
/// RLS scopes `orders` (and its joined tables) to the signed-in owner's
/// store, so no explicit store_id filter is needed here -- same
/// assumption as StoreProvider / ProductProvider.
class IncomingOrderProvider extends ChangeNotifier {
  final SupabaseClient _client = Supabase.instance.client;

  RealtimeChannel? _channel;
  List<IncomingOrder> _orders = [];
  bool isLoading = false;
  Object? loadError;
  bool _hasLoadedOnce = false;
  bool _disposed = false;

  List<IncomingOrder> get orders => _orders;
  List<IncomingOrder> get pending => _orders.where((o) => o.status == 'pending').toList();
  List<IncomingOrder> get recent => _orders.where((o) => o.status != 'pending').toList();
  int get pendingCount => _orders.where((o) => o.status == 'pending').length;

  /// Safe to call repeatedly (a new HomeShell after every PIN login
  /// calls it again) -- any old subscription is closed first.
  Future<void> start() async {
    await stop();
    await load();
    _channel = _client
        .channel('incoming-orders')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'orders',
          callback: (_) => load(),
        )
        .subscribe();
  }

  Future<void> stop() async {
    final channel = _channel;
    _channel = null;
    if (channel != null) {
      try {
        await _client.removeChannel(channel);
      } catch (_) {}
    }
  }

  /// Last two days of orders, newest first. Older ones aren't useful on
  /// a cashier screen and would just grow the list forever.
  Future<void> load() async {
    if (_disposed) return;
    if (!_hasLoadedOnce) {
      isLoading = true;
      notifyListeners();
    }
    try {
      final since = DateTime.now().subtract(const Duration(days: 2)).toUtc().toIso8601String();
      final rows = await _client
          .from('orders')
          .select(
            'id, status, total, customer_name, created_at, '
            'payment_method, payment_status, payment_reference, '
            'tables(label), '
            'order_items(quantity, price, variant_name, products(name))',
          )
          .gte('created_at', since)
          .order('created_at', ascending: false)
          .limit(100);

      final next = (rows as List)
          .map((r) => IncomingOrder.fromRow(Map<String, dynamic>.from(r as Map)))
          .toList();

      final before = pendingCount;
      _orders = next;
      // Audible nudge only for orders that arrive while the app is open,
      // not for the ones already waiting when it first loads.
      if (_hasLoadedOnce && pendingCount > before) {
        SystemSound.play(SystemSoundType.alert);
      }
      _hasLoadedOnce = true;
      loadError = null;
    } catch (e) {
      loadError = e;
      debugPrint('IncomingOrderProvider.load failed: $e');
    }
    isLoading = false;
    if (!_disposed) notifyListeners();
  }

  Future<void> accept(IncomingOrder order) => _update(order.id, {'status': 'accepted'});

  Future<void> reject(IncomingOrder order) => _update(order.id, {'status': 'rejected'});

  /// The cashier has confirmed the money arrived (checked their e-wallet
  /// for an online order, or took payment at the counter).
  Future<void> markPaid(IncomingOrder order) => _update(order.id, {'payment_status': 'paid'});

  Future<void> _update(String id, Map<String, dynamic> patch) async {
    final res = await _client
        .from('orders')
        .update({...patch, 'updated_at': DateTime.now().toUtc().toIso8601String()})
        .eq('id', id)
        .select('id');
    // An RLS-blocked update returns zero rows instead of throwing; surface
    // that rather than pretending the tap worked.
    if ((res as List).isEmpty) {
      throw StateError('The order could not be updated.');
    }
    await load();
  }

  @override
  void dispose() {
    _disposed = true;
    final channel = _channel;
    _channel = null;
    if (channel != null) {
      _client.removeChannel(channel);
    }
    super.dispose();
  }
}
